/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package simplethread;

/**
 *
 * @author Admin
 */
public class SimpleThread extends Thread {
    @Override 
public void run() { 
    System.out.println(Thread.currentThread().getId() + " is executing the thread.");
 
    }


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        SimpleThread thread1 = new SimpleThread(); 
        SimpleThread thread2 = new SimpleThread(); 
 

        thread1.start();  // Starts thread1 
        thread2.start();  // Starts thread2 

    
}  
}
