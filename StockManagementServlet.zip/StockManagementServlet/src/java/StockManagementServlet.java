import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/StockManagementServlet")
public class StockManagementServlet extends HttpServlet {

    // In-memory stock list: ProductName -> Quantity
    private static HashMap<String, Integer> stockList = new HashMap<>();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String productName = request.getParameter("product_name").trim();
        String quantityStr = request.getParameter("quantity");
        String action = request.getParameter("action");

        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {
            out.println("<html><body>");
            out.println("<h2>Stock Management System</h2>");

            if (productName.isEmpty() || quantityStr.isEmpty()) {
                out.println("<p style='color:red;'>Please enter all fields.</p>");
            } else {
                int quantity = Integer.parseInt(quantityStr);

                switch (action) {
                    case "Add Product":
                        stockList.put(productName, quantity);
                        out.println("<p>Product <strong>" + productName + "</strong> added with quantity: " + quantity + "</p>");
                        break;
                    case "Update Product":
                        if (stockList.containsKey(productName)) {
                            stockList.put(productName, quantity);
                            out.println("<p>Product <strong>" + productName + "</strong> updated to quantity: " + quantity + "</p>");
                        } else {
                            out.println("<p style='color:red;'>Product not found for update.</p>");
                        }
                        break;
                    case "Delete Product":
                        if (stockList.containsKey(productName)) {
                            stockList.remove(productName);
                            out.println("<p>Product <strong>" + productName + "</strong> deleted.</p>");
                        } else {
                            out.println("<p style='color:red;'>Product not found for deletion.</p>");
                        }
                        break;
                }
            }

            out.println("<br><a href='stock.html'>Go Back</a>");
            out.println("</body></html>");
        }
    }
}
